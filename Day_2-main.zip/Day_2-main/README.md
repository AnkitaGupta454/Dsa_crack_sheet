# Day_2
This is day 2 of dsa crack sheet (Questions on array)
